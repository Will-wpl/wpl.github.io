$(document).ready(function(){
	$("#notice_detail h3").text(pagedata.noticedetail.title);
	$("#notice_detail p").text(pagedata.noticedetail.content);
})
